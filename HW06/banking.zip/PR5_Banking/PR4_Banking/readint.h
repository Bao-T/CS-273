#ifndef READ_INT_H_
#define READ_INT_H_

#include <string>

// Function prototype for read_int
int read_int(const std::string &prompt, int low, int high);


#endif